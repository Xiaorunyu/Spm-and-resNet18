import numpy as np
import visual_recog
import visual_words
import util
import skimage.transform
import numpy as np
import multiprocessing
import imageio
import scipy.ndimage
import skimage.color
import sklearn.cluster
import scipy.spatial.distance
import os,time
import util
import random
import math

def extract_filter_responses_rs(image):
    '''
    Extracts the filter responses for the given image.

    [input]
    * image: numpy.ndarray of shape (H,W) or (H,W,3)

    [output]
    * filter_responses: numpy.ndarray of shape (H,W,3F)
    '''

    # ----- TODO -----
    image1 = imageio.imread(image)
    image1=skimage.transform.resize(image1,(100,100))
    image1=image1-np.mean(image1)
    if image1.shape[2] == 0:
        # stacked_img = np.stack((image1,) * 3, axis=-1)
        # image1=image1.shape+(1,)+(1,)
        image1[:, :, 1] = image1[:, :, 0]
        image1[:, :, 2] = image1[:, :, 0]
    if image1.shape[2] == 4:
        image1 = image1[:, :, :3]
    image1 = image1.astype(float) / 255.0
    image1 = skimage.color.rgb2lab(image1)
    s = np.zeros((image1[:, :, 0].shape))
    for j in range(4):
        for i in range(3):
            s = np.dstack((s, scipy.ndimage.gaussian_filter(image1[:, :, i], sigma=2 ** j, mode='nearest')))
        for i in range(3):
            s = np.dstack((s, scipy.ndimage.gaussian_laplace(image1[:, :, i], sigma=2 ** j, mode='nearest')))
        for i in range(3):
            s = np.dstack(
                (s, scipy.ndimage.gaussian_filter1d(image1[:, :, i], order=1, axis=1, sigma=2 ** j, mode='nearest')))
        for i in range(3):
            s = np.dstack(
                (s, scipy.ndimage.gaussian_filter1d(image1[:, :, i], order=1, axis=0, sigma=2 ** j, mode='nearest')))
    for i in range(3):
        s = np.dstack((s, scipy.ndimage.gaussian_filter(image1[:, :, i], sigma=8 * (2 ** 0.5), mode='nearest')))
    for i in range(3):
        s = np.dstack((s, scipy.ndimage.gaussian_laplace(image1[:, :, i], sigma=8 * (2 ** 0.5), mode='nearest')))
    for i in range(3):
        s = np.dstack((s, scipy.ndimage.gaussian_filter1d(image1[:, :, i], order=1, axis=1, sigma=8 * (2 ** 0.5),
                                                          mode='nearest')))
    for i in range(3):
        s = np.dstack((s, scipy.ndimage.gaussian_filter1d(image1[:, :, i], order=1, axis=0, sigma=8 * (2 ** 0.5),
                                                          mode='nearest')))
    s = s[:, :, 1:]
    # util.display_filter_responses(s)
    pass
    return s


def get_visual_words(image, dictionary):
    '''
    Compute visual words mapping for the given image using the dictionary of visual words.

    [input]
    * image: numpy.ndarray of shape (H,W) or (H,W,3)

    [output]
    * wordmap: numpy.ndarray of shape (H,W)
    '''

    # ----- TODO -----
    pass
    ori_img = extract_filter_responses_rs(image)
    transimg = ori_img.reshape(-1, 60)
    valmatrix = scipy.spatial.distance.cdist(dictionary, transimg)
    min_index = np.argmin(valmatrix, axis=0)
    wordmap = np.zeros((transimg.shape[0]))
    for i in range(len(wordmap)):
        wordmap[i] = min_index[i]
    wordmap = wordmap.reshape(ori_img.shape[0], ori_img.shape[1])
    return wordmap


# dictionary=np.load('dictionary.npy')
# wd1=get_visual_words('../data/park/labelme_pbpvrqbmgpebras.jpg',dictionary)
# wd2=get_visual_words('../data/aquarium/sun_ahyyislfsjgqxbmo.jpg',dictionary)
# wd3=get_visual_words('../data/kitchen/sun_avuzlcqxzrzteyvc.jpg',dictionary)
# util.save_wordmap(wd1, 'wordmap1')
# util.save_wordmap(wd2, 'wordmap2')
# util.save_wordmap(wd3, 'wordmap3')
def compute_dictionary_one_image(args):
    '''
    Extracts random samples of the dictionary entries from an image.
    This is a function run by a subprocess.

    [input]
    * i: index of training image
    * alpha: number of random samples
    * image_path: path of image file
    * time_start: time stamp of start time

    [saved]
    * sampled_response: numpy.ndarray of shape (alpha,3F)
    '''

    i, alpha, image_path = args
    # ----- TODO -----
    pass
    img = extract_filter_responses_rs(image_path)
    x = (img.shape[0] * np.random.random_sample(alpha)).astype(int)
    y = (img.shape[1] * np.random.random_sample(alpha)).astype(int)
    z = np.zeros((alpha, 60))
    for j in range(alpha):
        z[j, :] = img[x[j], y[j], :]
    np.save('sample' + str(i) + '.npy', z)
    return


# compute_dictionary_one_image([0,3,'../data/aquarium/sun_aztvjgubyrgvirup.jpg'])
def compute_dictionary(num_workers=2):
    '''
    Creates the dictionary of visual words by clustering using k-means.

    [input]
    * num_workers: number of workers to process in parallel

    [saved]
    * dictionary: numpy.ndarray of shape (K,3F)
    '''

    train_data = np.load("../data/train_data.npz")
    # ----- TODO -----
    pass
    index = 0
    texon_map = np.zeros((500, 60))
    for i in train_data['files']:
        compute_dictionary_one_image([index, 500, '../data/' + i])
        temp = np.load('sample' + str(index) + '.npy')
        index += 1
        texon_map = np.vstack((texon_map, temp))
        # print('已经构建'+str(index+1)+'张图片!!!')
        # print(texon_map.shape)
    texon_map = texon_map[500:, :]
    kmeans = sklearn.cluster.KMeans(n_clusters=150).fit(texon_map)
    dictionary = kmeans.cluster_centers_
    np.save('dictionary_tested.npy', dictionary)
    # print(dictionary.shape)
    return


def build_recognition_system(num_workers=2):
    '''
    Creates a trained recognition system by generating training features from all training images.

    [input]
    * num_workers: number of workers to process in parallel

    [saved]
    * features: numpy.ndarray of shape (N,M)
    * labels: numpy.ndarray of shape (N)
    * dictionary: numpy.ndarray of shape (K,3F)
    * SPM_layer_num: number of spatial pyramid layers
    '''

    train_data = np.load("../data/train_data.npz")
    dictionary = np.load("dictionary_tested.npy")
    # ----- TODO -----

    pass
    wordhist = np.zeros((3150))
    labels = []
    count = 0
    for j in train_data['labels']:
        labels.append(j)
    labels = np.array(labels)
    for i in train_data['files']:
        count += 1
        wordhist = np.vstack((wordhist, get_image_feature(i, dictionary, 2, 150)))
        # print('add'+str(count)+'pictures')
    features = wordhist[1:, :]
    # print(features.shape)
    SPM_layer_num = 2
    np.savez('trained system_tested.npz', dictionary=dictionary, labels=labels, features=features, SPM_layer_num=SPM_layer_num)





def evaluate_recognition_system(num_workers=2):
    '''
    Evaluates the recognition system for all test images and returns the confusion matrix.

    [input]
    * num_workers: number of workers to process in parallel

    [output]
    * conf: numpy.ndarray of shape (8,8)
    * accuracy: accuracy of the evaluated system
    '''

    test_data = np.load("../data/test_data.npz")
    trained_system = np.load("trained system_tested.npz")
    # ----- TODO -----
    pass
    train_labels = trained_system['labels']
    dictionary = trained_system['dictionary']
    confusion_matrix = np.zeros((8, 8))
    count = 0
    for i in test_data['files']:
        wordmap = visual_words.get_visual_words("../data/" + i, dictionary)
        wordhist = get_feature_from_wordmap_SPM(wordmap, 2, 150)
        x = train_labels[np.argmax(distance_to_set(wordhist, trained_system['features']))]
        y = test_data['labels'][count]
        print(x, y)
        confusion_matrix[x, y] += 1
        count += 1
    accuracy = 0
    for j in range(8):
        accuracy += confusion_matrix[j, j]
    print(accuracy)
    accuracy /= sum(confusion_matrix)
    print(confusion_matrix,accuracy)
    return confusion_matrix, accuracy

def evaluate_recognition_system_dis(num_workers=2):
    '''
    Evaluates the recognition system for all test images and returns the confusion matrix.

    [input]
    * num_workers: number of workers to process in parallel

    [output]
    * conf: numpy.ndarray of shape (8,8)
    * accuracy: accuracy of the evaluated system
    '''

    test_data = np.load("../data/test_data.npz")
    trained_system = np.load("trained_system.npz")
    # ----- TODO -----
    pass
    train_labels = trained_system['labels']
    dictionary = trained_system['dictionary']
    confusion_matrix = np.zeros((8, 8))
    count = 0
    for i in test_data['files']:
        wordmap = visual_words.get_visual_words("../data/" + i, dictionary)
        wordhist = get_feature_from_wordmap_SPM(wordmap, 2, 150)
        x = train_labels[np.argmax(distance_to_set1(wordhist, trained_system['features']))]
        y = test_data['labels'][count]
        print(x, y)
        confusion_matrix[x, y] += 1
        count += 1
    accuracy = 0
    for j in range(8):
        accuracy += confusion_matrix[j, j]
    print(accuracy)
    accuracy /= sum(confusion_matrix)
    print(confusion_matrix,accuracy)
    return confusion_matrix, accuracy

def get_image_feature(file_path, dictionary, layer_num, K):
    '''
    Extracts the spatial pyramid matching feature.

    [input]
    * file_path: path of image file to read
    * dictionary: numpy.ndarray of shape (K,3F)
    * layer_num: number of spatial pyramid layers
    * K: number of clusters for the word maps

    [output]
    * feature: numpy.ndarray of shape (K)
    '''
    pass

    # ----- TODO -----
    wordmap = visual_words.get_visual_words("../data/" + file_path, dictionary)
    wordhist = get_feature_from_wordmap_SPM(wordmap, 2, dictionary.shape[0])
    return wordhist

def distance_to_set(word_hist, histograms):
    '''
    Compute similarity between a histogram of visual words with all training image histograms.

    [input]
    * word_hist: numpy.ndarray of shape (K)
    * histograms: numpy.ndarray of shape (N,K)

    [output]
    * sim: numpy.ndarray of shape (N)
    '''
    pass
    new_word_hist = np.tile(word_hist, (histograms.shape[0], 1))
    sim =np.sum(np.minimum(new_word_hist, histograms), axis=1)
    return sim



def distance_to_set1(word_hist, histograms):
    '''
    Compute similarity between a histogram of visual words with all training image histograms.

    [input]
    * word_hist: numpy.ndarray of shape (K)
    * histograms: numpy.ndarray of shape (N,K)

    [output]
    * sim: numpy.ndarray of shape (N)
    '''
    pass
    new_word_hist = np.tile(word_hist, (histograms.shape[0], 1))
    sim = np.divide(np.sum(np.minimum(new_word_hist, histograms), axis=1),np.var(np.minimum(new_word_hist, histograms),axis=1))
    return sim

    # ----- TODO -----


def get_feature_from_wordmap(wordmap, dict_size):
    '''
    Compute histogram of visual words.

    [input]
    * wordmap: numpy.ndarray of shape (H,W)
    * dict_size: dictionary size K

    [output]
    * hist: numpy.ndarray of shape (K)
    '''

    # ----- TODO -----
    pass
    # wordmap=wordmap.flatten()
    hist = np.array(np.histogram(wordmap, bins=dict_size))[0] / (wordmap.shape[0] * wordmap.shape[1])
    print(hist)
    print(sum(hist))
    return hist


# Dic=np.load('dictionary.npy')
# wp=visual_words.get_visual_words('../data/aquarium/sun_aairflxfskjrkepm.jpg',Dic)
# get_feature_from_wordmap(wp,150)


def get_feature_from_wordmap_SPM(wordmap, layer_num, dict_size):
    '''
    Compute histogram of visual words using spatial pyramid matching.

    [input]
    * wordmap: numpy.ndarray of shape (H,W)
    * layer_num: number of spatial pyramid layers
    * dict_size: dictionary size K

    [output]
    * hist_all: numpy.ndarray of shape (K*(4^layer_num-1)/3)
    '''

    # ----- TODO -----

    pass
    lv0 = 0.25 * np.array(np.histogram(wordmap, bins=dict_size))[0]

    wp1, wp2, wp3, wp4 = np.array_split(wordmap, 4)
    lv1 = np.zeros((dict_size))
    for i in [wp1, wp2, wp3, wp4]:
        lv1 = np.hstack((lv1, 0.25 * np.array(np.histogram(i, bins=dict_size))[0]))
    lv1 = lv1[dict_size:]

    lv2 = np.zeros((dict_size))
    wp = np.array_split(wordmap, 16)
    for j in wp:
        lv2 = np.hstack((lv2, 0.5 * np.array(np.histogram(j, bins=dict_size))[0]))
    lv2 = lv2[dict_size:]
    hist_all = np.hstack((lv0, lv1, lv2))
    hist_all = hist_all / np.sum(hist_all)
    return hist_all

if __name__ == '__main__':
    num_cores = util.get_num_CPU()
    compute_dictionary(num_workers=num_cores)
    build_recognition_system()
    conf,accu=evaluate_recognition_system()
    conf1,accu1=evaluate_recognition_system_dis()
    print(conf)
    print(accu)
    print(conf1,accu1)