import numpy as np
import threading
import queue
import imageio
import os,time
import math
import visual_words

def build_recognition_system(num_workers=2):
    '''
    Creates a trained recognition system by generating training features from all training images.

    [input]
    * num_workers: number of workers to process in parallel

    [saved]
    * features: numpy.ndarray of shape (N,M)
    * labels: numpy.ndarray of shape (N)
    * dictionary: numpy.ndarray of shape (K,3F)
    * SPM_layer_num: number of spatial pyramid layers
    '''



    train_data = np.load("../data/train_data.npz")
    dictionary = np.load("dictionary.npy")
    # ----- TODO -----

    pass
    wordhist=np.zeros((3150))
    labels=[]
    count=0
    for j in train_data['labels']:
        labels.append(j)
    labels=np.array(labels)
    for i in train_data['files']:
        count+=1
        wordhist=np.vstack((wordhist,get_image_feature(i,dictionary,2,150)))
        #print('add'+str(count)+'pictures')
    features=wordhist[1:,:]
    #print(features.shape)
    SPM_layer_num=2
    np.savez('trained_system.npz',dictionary=dictionary,labels=labels,features=features,SPM_layer_num=SPM_layer_num)





def evaluate_recognition_system(num_workers=2):
    '''
    Evaluates the recognition system for all test images and returns the confusion matrix.

    [input]
    * num_workers: number of workers to process in parallel

    [output]
    * conf: numpy.ndarray of shape (8,8)
    * accuracy: accuracy of the evaluated system
    '''


    test_data = np.load("../data/test_data.npz")
    trained_system = np.load("trained_system.npz")
    # ----- TODO -----
    pass
    train_labels=trained_system['labels']
    dictionary=trained_system['dictionary']
    confusion_matrix=np.zeros((8,8))
    count=0
    for i in test_data['files']:
        wordmap=visual_words.get_visual_words("../data/"+i,dictionary)
        wordhist=get_feature_from_wordmap_SPM(wordmap,2,150)
        x=train_labels[np.argmax(distance_to_set(wordhist,trained_system['features']))]
        y=test_data['labels'][count]
        print(x,y)
        confusion_matrix[x,y]+=1
        count+=1
    accuracy=0
    for j in range(8):
        accuracy+=confusion_matrix[j,j]
    accuracy/=sum(confusion_matrix)
    #print(confusion_matrix,accuracy)
    return confusion_matrix,accuracy





def get_image_feature(file_path,dictionary,layer_num,K):
    '''
    Extracts the spatial pyramid matching feature.

    [input]
    * file_path: path of image file to read
    * dictionary: numpy.ndarray of shape (K,3F)
    * layer_num: number of spatial pyramid layers
    * K: number of clusters for the word maps

    [output]
    * feature: numpy.ndarray of shape (K)
    '''
    pass


    # ----- TODO -----
    wordmap =visual_words.get_visual_words("../data/" + file_path, dictionary)
    wordhist=get_feature_from_wordmap_SPM(wordmap,2,dictionary.shape[0])
    return wordhist

def distance_to_set(word_hist,histograms):
    '''
    Compute similarity between a histogram of visual words with all training image histograms.

    [input]
    * word_hist: numpy.ndarray of shape (K)
    * histograms: numpy.ndarray of shape (N,K)

    [output]
    * sim: numpy.ndarray of shape (N)
    '''
    pass
    new_word_hist=np.tile(word_hist,(histograms.shape[0],1))
    sim=np.sum(np.minimum(new_word_hist,histograms),axis=1)
    return sim

    # ----- TODO -----



def get_feature_from_wordmap(wordmap,dict_size):
    '''
    Compute histogram of visual words.

    [input]
    * wordmap: numpy.ndarray of shape (H,W)
    * dict_size: dictionary size K

    [output]
    * hist: numpy.ndarray of shape (K)
    '''

    # ----- TODO -----
    pass
    #wordmap=wordmap.flatten()
    hist=np.array(np.histogram(wordmap,bins=dict_size))[0]/(wordmap.shape[0]*wordmap.shape[1])
    print(hist)
    print(sum(hist))
    return hist
#Dic=np.load('dictionary.npy')
#wp=visual_words.get_visual_words('../data/aquarium/sun_aairflxfskjrkepm.jpg',Dic)
#get_feature_from_wordmap(wp,150)


def get_feature_from_wordmap_SPM(wordmap,layer_num,dict_size):
    '''
    Compute histogram of visual words using spatial pyramid matching.

    [input]
    * wordmap: numpy.ndarray of shape (H,W)
    * layer_num: number of spatial pyramid layers
    * dict_size: dictionary size K

    [output]
    * hist_all: numpy.ndarray of shape (K*(4^layer_num-1)/3)
    '''
    
    # ----- TODO -----

    pass
    lv0 = 0.25*np.array(np.histogram(wordmap, bins=dict_size))[0]

    wp1,wp2,wp3,wp4=np.array_split(wordmap,4)
    lv1=np.zeros((dict_size))
    for i in [wp1,wp2,wp3,wp4]:
        lv1=np.hstack((lv1,0.25 * np.array(np.histogram(i, bins=dict_size))[0]))
    lv1=lv1[dict_size:]

    lv2=np.zeros((dict_size))
    wp=np.array_split(wordmap,16)
    for j in wp:
        lv2=np.hstack((lv2,0.5 * np.array(np.histogram(j, bins=dict_size))[0]))
    lv2=lv2[dict_size:]

    hist_all=np.hstack((lv0,lv1,lv2))
    hist_all=hist_all/np.sum(hist_all)
    return hist_all

#wh=get_feature_from_wordmap_SPM(wp,2,150)
#newwh=np.tile(wh,(10,1))
#distance_to_set(wh,newwh)

#build_recognition_system()
#evaluate_recognition_system()