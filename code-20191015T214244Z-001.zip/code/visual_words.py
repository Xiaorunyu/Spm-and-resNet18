import numpy as np
import multiprocessing
import imageio
import scipy.ndimage
import skimage.color
import sklearn.cluster
import scipy.spatial.distance
import os,time
import util
import random

def extract_filter_responses(image):
    '''
    Extracts the filter responses for the given image.

    [input]
    * image: numpy.ndarray of shape (H,W) or (H,W,3)

    [output]
    * filter_responses: numpy.ndarray of shape (H,W,3F)
    '''
    
    # ----- TODO -----
    image1 = imageio.imread(image)
    if image1.shape[2]==0:
        #stacked_img = np.stack((image1,) * 3, axis=-1)
        #image1=image1.shape+(1,)+(1,)
        image1[:,:,1]=image1[:,:,0]
        image1[:,:,2]=image1[:,:,0]
    if image1.shape[2] == 4:
        image1 = image1[:, :, :3]
    image1 = image1.astype(float) / 255.0
    image1 = skimage.color.rgb2lab(image1)
    s=np.zeros((image1[:,:,0].shape))
    for j in range(4):
        for i in range(3):
            s=np.dstack((s,scipy.ndimage.gaussian_filter(image1[:,:,i],sigma=2**j,mode='nearest')))
        for i in range(3):
            s=np.dstack((s,scipy.ndimage.gaussian_laplace(image1[:,:,i],sigma=2**j,mode='nearest')))
        for i in range(3):
            s = np.dstack((s, scipy.ndimage.gaussian_filter1d(image1[:, :, i], order=1, axis=1, sigma=2 ** j, mode='nearest')))
        for i in range(3):
            s = np.dstack((s, scipy.ndimage.gaussian_filter1d(image1[:, :, i], order=1, axis=0, sigma=2 ** j, mode='nearest')))
    for i in range(3):
        s = np.dstack((s, scipy.ndimage.gaussian_filter(image1[:, :, i], sigma=8 * (2 ** 0.5), mode='nearest')))
    for i in range(3):
        s=np.dstack((s,scipy.ndimage.gaussian_laplace(image1[:, :, i], sigma=8*(2**0.5), mode='nearest')))
    for i in range(3):
        s=np.dstack((s,scipy.ndimage.gaussian_filter1d(image1[:,:,i],order=1,axis=1,sigma=8*(2**0.5),mode='nearest')))
    for i in range(3):
        s=np.dstack((s,scipy.ndimage.gaussian_filter1d(image1[:,:,i],order=1,axis=0,sigma=8*(2**0.5),mode='nearest')))
    s=s[:,:,1:]
    #util.display_filter_responses(s)
    pass
    return s
#x=extract_filter_responses('../data/aquarium/sun_aztvjgubyrgvirup.jpg')
def get_visual_words(image,dictionary):
    '''
    Compute visual words mapping for the given image using the dictionary of visual words.

    [input]
    * image: numpy.ndarray of shape (H,W) or (H,W,3)
    
    [output]
    * wordmap: numpy.ndarray of shape (H,W)
    '''
    
    # ----- TODO -----
    pass
    ori_img=extract_filter_responses(image)
    transimg=ori_img.reshape(-1,60)
    valmatrix=scipy.spatial.distance.cdist(dictionary,transimg)
    min_index=np.argmin(valmatrix, axis=0)
    wordmap=np.zeros((transimg.shape[0]))
    for i in range(len(wordmap)):
        wordmap[i]=min_index[i]
    wordmap=wordmap.reshape(ori_img.shape[0],ori_img.shape[1])
    return wordmap
dictionary=np.load('dictionary.npy')
wd1=get_visual_words('../data/park/labelme_pbpvrqbmgpebras.jpg',dictionary)
#wd2=get_visual_words('../data/aquarium/sun_ahyyislfsjgqxbmo.jpg',dictionary)
#wd3=get_visual_words('../data/kitchen/sun_avuzlcqxzrzteyvc.jpg',dictionary)
util.save_wordmap(wd1, 'wordmap1')
#util.save_wordmap(wd2, 'wordmap2')
#util.save_wordmap(wd3, 'wordmap3')
def compute_dictionary_one_image(args):
    '''
    Extracts random samples of the dictionary entries from an image.
    This is a function run by a subprocess.

    [input]
    * i: index of training image
    * alpha: number of random samples
    * image_path: path of image file
    * time_start: time stamp of start time

    [saved]
    * sampled_response: numpy.ndarray of shape (alpha,3F)
    '''


    i,alpha,image_path = args
    # ----- TODO -----
    pass
    img=extract_filter_responses(image_path)
    x=(img.shape[0]*np.random.random_sample(alpha)).astype(int)
    y=(img.shape[1]*np.random.random_sample(alpha)).astype(int)
    z=np.zeros((alpha,60))
    for j in range(alpha):
        z[j,:]=img[x[j],y[j],:]
    np.save('sample'+str(i)+'.npy',z)
    return
#compute_dictionary_one_image([0,3,'../data/aquarium/sun_aztvjgubyrgvirup.jpg'])
def compute_dictionary(num_workers=2):
    '''
    Creates the dictionary of visual words by clustering using k-means.

    [input]
    * num_workers: number of workers to process in parallel
    
    [saved]
    * dictionary: numpy.ndarray of shape (K,3F)
    '''

    train_data = np.load("../data/train_data.npz")
    # ----- TODO -----
    pass
    index=0
    texon_map=np.zeros((500,60))
    for i in train_data['files']:
        compute_dictionary_one_image([index,500,'../data/'+i])
        temp=np.load('sample'+str(index)+'.npy')
        index += 1
        texon_map=np.vstack((texon_map,temp))
        #print('已经构建'+str(index+1)+'张图片!!!')
        #print(texon_map.shape)
    texon_map=texon_map[500:,:]
    kmeans = sklearn.cluster.KMeans(n_clusters=150).fit(texon_map)
    dictionary = kmeans.cluster_centers_
    np.save('dictionary.npy',dictionary)
    #print(dictionary.shape)
    return
#compute_dictionary()
#Dic=np.load('dictionary.npy')
#word_map=get_visual_words('../data/aquarium/sun_aairflxfskjrkepm.jpg',Dic)